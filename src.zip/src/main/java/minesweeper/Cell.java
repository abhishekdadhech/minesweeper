package minesweeper;

import processing.core.PApplet;
import processing.core.PImage;

public class Cell {
    private int x, y;
    private boolean mine;
    private boolean revealed;
    private boolean flagged;
    private int adjacentMines;
    private int explosionFrame;
    private boolean exploding;

    // Images
    private PImage tileImage;
    private PImage flagImage;
    private PImage[] mineImages;

    public Cell(int x, int y, PImage tileImage, PImage flagImage, PImage[] mineImages) {
        this.x = x;
        this.y = y;
        this.tileImage = tileImage;
        this.flagImage = flagImage;
        this.mineImages = mineImages;
        this.mine = false;
        this.revealed = false;
        this.flagged = false;
        this.adjacentMines = 0;
        this.explosionFrame = 0;
        this.exploding = false;
    }

    public void setMine(boolean mine) {
        this.mine = mine;
    }

    public boolean hasMine() {
        return mine;
    }

    public void reveal() {
        if (!flagged) {
            revealed = true;
        }
    }

    public void toggleFlag() {
        flagged = !flagged;
    }

    public boolean isRevealed() {
        return revealed;
    }

    public void triggerExplosion() {
        exploding = true;
        explosionFrame = 0;
    }

    public void calculateAdjacentMines(Cell[][] board, int width, int height) {
        if (mine) return;

        int count = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int nx = x + dx;
                int ny = y + dy;
                if (nx >= 0 && ny >= 0 && nx < width && ny < height && board[nx][ny].hasMine()) {
                    count++;
                }
            }
        }
        adjacentMines = count;
    }

    public void draw(PApplet app) {
        int xPos = x * App.CELLSIZE;
        int yPos = y * App.CELLSIZE + App.TOPBAR;

        if (revealed) {
            if (mine) {
                if (exploding && explosionFrame < mineImages.length) {
                    app.image(mineImages[explosionFrame], xPos, yPos, App.CELLSIZE, App.CELLSIZE);
                    if (app.frameCount % 3 == 0) {
                        explosionFrame++;
                    }
                } else {
                    app.image(mineImages[mineImages.length - 1], xPos, yPos, App.CELLSIZE, App.CELLSIZE);
                }
            } else {
                app.fill(200);
                app.rect(xPos, yPos, App.CELLSIZE, App.CELLSIZE);

                if (adjacentMines > 0) {
                    app.fill(0);
                    app.textAlign(PApplet.CENTER, PApplet.CENTER);
                    app.textSize(20);
                    app.text(adjacentMines, xPos + App.CELLSIZE / 2, yPos + App.CELLSIZE / 2);
                }
            }
        } else {
            app.image(tileImage, xPos, yPos, App.CELLSIZE, App.CELLSIZE);

            if (flagged) {
                app.image(flagImage, xPos, yPos, App.CELLSIZE, App.CELLSIZE); // Draw flag image
            }
        }
    }
}