package minesweeper;

import processing.core.PApplet;
import processing.core.PImage;
import java.util.Random;

public class App extends PApplet {

    // Constants for grid and game settings
    public static final int CELLSIZE = 32;
    public static final int BOARD_WIDTH = 27; // Number of tiles horizontally
    public static final int BOARD_HEIGHT = 18; // Number of tiles vertically
    public static final int MINES_COUNT = 100; // Default number of mines
    public static final int TOPBAR = 64; // Space at the top for timer, messages, etc.
    public static final int FPS = 30;

    // Game state variables
    public char[][] Mines = new char[BOARD_WIDTH][BOARD_HEIGHT];
    public boolean[][] revealed = new boolean[BOARD_WIDTH][BOARD_HEIGHT];
    public boolean[][] flagged = new boolean[BOARD_WIDTH][BOARD_HEIGHT];
    public boolean gameLost = false;
    public boolean gameWon = false;
    public int elapsedTime = 0; // Time in seconds since game started
    public int framesCount = 0; // Frame counter to track time

    public static Random random = new Random();

    // Images
    PImage flagImg; // Flag image for the cells

    @Override
    public void settings() {
        size(BOARD_WIDTH * CELLSIZE, BOARD_HEIGHT * CELLSIZE + TOPBAR);
    }

    @Override
    public void setup() {
        frameRate(FPS);
        flagImg = loadImage("flag.png"); // Load the provided flag image
        initializeBoard();
    }

    public void initializeBoard() {
        // Initialize the board and state variables
        for (int i = 0; i < BOARD_WIDTH; i++) {
            for (int j = 0; j < BOARD_HEIGHT; j++) {
                Mines[i][j] = ' ';
                revealed[i][j] = false;
                flagged[i][j] = false;
            }
        }
        gameLost = false;
        gameWon = false;
        elapsedTime = 0;
        framesCount = 0;
        MineGenerator();
        NumberGenerator();
    }

    private void MineGenerator() {
        int i = 0;
        while (i < MINES_COUNT) {
            int x = random.nextInt(BOARD_WIDTH);
            int y = random.nextInt(BOARD_HEIGHT);
            if (Mines[x][y] != 'x') {
                Mines[x][y] = 'x';
                i++;
            }
        }
    }

    private void NumberGenerator() {
        for (int i = 0; i < BOARD_WIDTH; i++) {
            for (int j = 0; j < BOARD_HEIGHT; j++) {
                if (Mines[i][j] != 'x') {
                    Mines[i][j] = (char) (countSurround(i, j) + '0');
                    if (Mines[i][j] == '0') Mines[i][j] = ' ';
                }
            }
        }
    }

    private int countSurround(int i, int j) {
        int count = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (i + dx >= 0 && i + dx < BOARD_WIDTH && j + dy >= 0 && j + dy < BOARD_HEIGHT) {
                    if (Mines[i + dx][j + dy] == 'x') count++;
                }
            }
        }
        return count;
    }

    @Override
    public void draw() {
        background(200);
        drawBoard();
        drawTopBar();

        // Increment time every second (every FPS frames)
        framesCount++;
        if (framesCount == FPS) {
            elapsedTime++;
            framesCount = 0;
        }
    }

    public void drawBoard() {
        for (int i = 0; i < BOARD_WIDTH; i++) {
            for (int j = 0; j < BOARD_HEIGHT; j++) {
                if (revealed[i][j]) {
                    if (Mines[i][j] == 'x') {
                        fill(255, 0, 0);  // Mine
                    } else {
                        fill(200);  // Revealed tile
                    }
                } else {
                    fill(100);  // Hidden tile
                }
                rect(i * CELLSIZE, j * CELLSIZE + TOPBAR, CELLSIZE, CELLSIZE);

                if (revealed[i][j] && Mines[i][j] != ' ' && Mines[i][j] != 'x') {
                    fill(0);
                    textAlign(CENTER, CENTER);
                    text(Mines[i][j], i * CELLSIZE + CELLSIZE / 2, j * CELLSIZE + CELLSIZE / 2 + TOPBAR);
                }

                if (flagged[i][j]) {
                    image(flagImg, i * CELLSIZE, j * CELLSIZE + TOPBAR, CELLSIZE, CELLSIZE);  // Draw flag
                }
            }
        }
    }

    public void drawTopBar() {
        // Draw timer and messages
        fill(0);
        textAlign(LEFT, CENTER);
        textSize(20);
        text("Time: " + elapsedTime, 10, 32);

        if (gameLost) {
            textAlign(CENTER, CENTER);
            textSize(40);
            text("You Lost! Press 'R' to Restart", width / 2, TOPBAR / 2); // Display restart message
        } else if (gameWon) {
            textAlign(CENTER, CENTER);
            textSize(40);
            text("You Win!", width / 2, TOPBAR / 2);
        }
    }

    @Override
    public void mousePressed() {
        if (gameLost || gameWon) return; // No interaction after game over
        int x = mouseX / CELLSIZE;
        int y = (mouseY - TOPBAR) / CELLSIZE;

        if (x >= 0 && x < BOARD_WIDTH && y >= 0 && y < BOARD_HEIGHT) {
            if (mouseButton == LEFT) {
                revealTile(x, y);
            } else if (mouseButton == RIGHT) {
                flagTile(x, y);
            }
        }
    }

    public void revealTile(int x, int y) {
        if (!flagged[x][y] && !revealed[x][y]) {
            revealed[x][y] = true;
            if (Mines[x][y] == 'x') {
                gameLost = true; // Hit a mine
            } else if (Mines[x][y] == ' ') {
                // Cascade reveal for empty tiles
                revealAdjacent(x, y);
            }
            checkWinCondition();
        }
    }

    public void flagTile(int x, int y) {
        if (!revealed[x][y]) {
            flagged[x][y] = !flagged[x][y];
        }
    }

    public void revealAdjacent(int x, int y) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int nx = x + dx;
                int ny = y + dy;
                if (nx >= 0 && nx < BOARD_WIDTH && ny >= 0 && ny < BOARD_HEIGHT && !revealed[nx][ny]) {
                    revealTile(nx, ny);
                }
            }
        }
    }

    public void checkWinCondition() {
        for (int i = 0; i < BOARD_WIDTH; i++) {
            for (int j = 0; j < BOARD_HEIGHT; j++) {
                if (Mines[i][j] != 'x' && !revealed[i][j]) {
                    return; // If any non-mine tile is still hidden, the game is not won
                }
            }
        }
        gameWon = true; // All non-mine tiles revealed
    }

    @Override
    public void keyPressed() {
        if (gameLost && key == 'r' || key == 'R') {
            initializeBoard(); // Restart the game when 'R' is pressed
        }
    }

    public static void main(String[] args) {
        PApplet.main("minesweeper.App");
    }
}